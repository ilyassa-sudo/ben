# Benabella Real AI Agent Setup

Use this only when you want the CRM AI Agent to answer like a real ChatGPT-style real estate mentor.

## 1. Create the private connector

1. Open Google Apps Script.
2. Create a new project.
3. Paste the full code from `ai-agent-google-apps-script.js`.
4. Open Project Settings.
5. Add Script Property:
   - `OPENAI_API_KEY` = your private OpenAI API key
   - Optional: `OPENAI_MODEL` = `gpt-4.1-mini`

Never put the OpenAI key in GitHub or inside the CRM website.

## 2. Deploy it

1. Click Deploy.
2. Choose Web app.
3. Execute as: Me.
4. Who has access: Anyone.
5. Copy the Web app URL.

## 3. Connect it in the CRM

1. Open Benabella CRM.
2. Go to AI Agent.
3. Open Real AI Brain.
4. Paste the Web app URL.
5. Turn on Use real AI.
6. Click Save AI Brain.

After this, the AI Agent uses the CRM data plus the private connector to answer questions, create tasks, analyze buyers/owners, and give growth advice.
