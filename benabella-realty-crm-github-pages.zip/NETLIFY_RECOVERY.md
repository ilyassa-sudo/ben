# Netlify Recovery

If the CRM URL is no longer live, restore it from Netlify instead of creating a new random site whenever possible.

## Best Option: Redeploy Same Site

1. Log in to Netlify.
2. Open the existing site for `regal-piroshki-35275a`.
3. Go to **Deploys**.
4. Drag the updated project folder or `benabella-realty-crm-deploy.zip` into the deploy area.
5. Wait for the deploy to finish.
6. Open `https://regal-piroshki-35275a.netlify.app/`.

This is best because browser data is linked to the exact website domain.

## If the Site Was Deleted

If Netlify says the site does not exist anymore, create a new site by uploading the deploy zip. The app will work, but old browser data from the deleted domain will not automatically appear on the new domain.

To protect data next time:

1. Open the CRM on the computer where the data exists.
2. Click **Backup Data**.
3. Save the JSON backup.
4. On the new site, click **Import** and choose that backup file.

## To Share PC and Phone Data

Use **Sync** with Supabase cloud setup, or use **One-Time Phone Transfer**:

1. PC: **Sync** -> **Copy Transfer Code**.
2. Phone: **Sync** -> paste code -> **Import Transfer Code**.
