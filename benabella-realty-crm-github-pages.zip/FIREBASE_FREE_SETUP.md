# Free Automatic Data: GitHub Pages + Firebase

This is the recommended free setup:

- **GitHub Pages** hosts the CRM for free.
- **Firebase Authentication** lets Ayoub/Youssef log in.
- **Cloud Firestore** stores shared CRM data.

After setup, phone and computer use the same data automatically. No transfer code and no manual sync.

## 1. Create Firebase Project

1. Go to https://console.firebase.google.com/
2. Create a project, for example `benabella-realty-crm`.
3. Stay on the free Spark plan.

## 2. Add Web App

1. In Firebase project settings, add a **Web app**.
2. Firebase gives you a config like:

```js
const firebaseConfig = {
  apiKey: "...",
  authDomain: "...",
  projectId: "...",
  storageBucket: "...",
  messagingSenderId: "...",
  appId: "..."
};
```

3. Copy those values into `firebase-config.js`.

## 3. Enable Email Login

1. Open **Authentication**.
2. Click **Get started**.
3. Enable **Email/Password**.
4. Add users for Ayoub and Youssef.

## 4. Create Firestore Database

1. Open **Firestore Database**.
2. Create a database.
3. Choose production mode.
4. Use a nearby region.

## 5. Firestore Rules

Use these rules:

```js
rules_version = '2';

service cloud.firestore {
  match /databases/{database}/documents {
    match /crmWorkspaces/{workspaceId} {
      allow read, write: if request.auth != null;
    }
  }
}
```

Only logged-in Firebase users can read/write the CRM.

## 6. Deploy Free

Use GitHub Pages with the updated files:

- `index.html`
- `styles.css`
- `app.js`
- `firebase-config.js`
- `assets/`
- `.nojekyll`

## 7. Use It

1. Open the CRM link on PC.
2. Go to **Sync**.
3. Log in under **Free Automatic Cloud**.
4. Click **Save To Cloud Now** once if your PC already has data.
5. Open the same CRM link on phone.
6. Go to **Sync** and log in with the same Firebase user.

The phone will load the shared cloud data automatically.
