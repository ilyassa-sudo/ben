# Free Hosting With GitHub Pages

Use this if Netlify is out of credits.

GitHub Pages can host this CRM for free because it is a static website.

## Important

GitHub Pages will host the app, but browser data is still stored per device unless you use:

- **Backup Data / Import**
- **Sync -> One-Time Phone Transfer**
- A future free shared database setup

## Steps

1. Go to https://github.com and create a free account if needed.
2. Create a new repository, for example:
   `benabella-realty-crm`
3. Upload these files/folders from this project:
   - `index.html`
   - `styles.css`
   - `app.js`
   - `assets/`
4. In the repository, open **Settings**.
5. Open **Pages**.
6. Under **Build and deployment**, choose:
   - Source: `Deploy from a branch`
   - Branch: `main`
   - Folder: `/root`
7. Save.
8. GitHub will give you a free live link like:
   `https://YOURUSERNAME.github.io/benabella-realty-crm/`

## Moving Your Current PC Data

Before switching domains:

1. Open the CRM on the PC where your data exists.
2. Click **Backup Data**.
3. Save the JSON file.
4. Open the new GitHub Pages link.
5. Click **Import** and choose the backup file.

For phone:

1. On PC, go to **Sync**.
2. Click **Copy Transfer Code**.
3. Send the code to your phone.
4. On phone, open the GitHub Pages CRM link.
5. Go to **Sync**.
6. Paste the code.
7. Click **Import Transfer Code**.

