const json = (statusCode, body) => ({
  statusCode,
  headers: {
    "Content-Type": "application/json",
    "Cache-Control": "no-store"
  },
  body: JSON.stringify(body)
});

exports.handler = async (event) => {
  const supabaseUrl = process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const syncSecret = process.env.CRM_SYNC_SECRET;

  if (!supabaseUrl || !serviceKey || !syncSecret) {
    return json(503, { error: "Cloud sync is not configured" });
  }

  if (event.headers["x-crm-sync-secret"] !== syncSecret) {
    return json(401, { error: "Invalid sync code" });
  }

  const workspace = event.queryStringParameters?.workspace || "benabella-realty";
  const tableUrl = `${supabaseUrl.replace(/\/$/, "")}/rest/v1/crm_state`;
  const headers = {
    apikey: serviceKey,
    Authorization: `Bearer ${serviceKey}`,
    "Content-Type": "application/json"
  };

  if (event.httpMethod === "GET") {
    const response = await fetch(`${tableUrl}?workspace_id=eq.${encodeURIComponent(workspace)}&select=data,updated_at`, {
      headers: { ...headers, Prefer: "return=representation" }
    });
    if (!response.ok) return json(response.status, { error: "Could not read cloud data" });
    const rows = await response.json();
    if (!rows.length) return json(404, { data: null });
    return json(200, rows[0]);
  }

  if (event.httpMethod === "PUT" || event.httpMethod === "POST") {
    const payload = JSON.parse(event.body || "{}");
    const response = await fetch(`${tableUrl}?on_conflict=workspace_id`, {
      method: "POST",
      headers: {
        ...headers,
        Prefer: "resolution=merge-duplicates,return=representation"
      },
      body: JSON.stringify({
        workspace_id: workspace,
        data: payload.data || {},
        updated_at: new Date().toISOString()
      })
    });
    if (!response.ok) return json(response.status, { error: "Could not save cloud data" });
    const rows = await response.json();
    return json(200, rows[0] || { data: payload.data || {} });
  }

  return json(405, { error: "Method not allowed" });
};
