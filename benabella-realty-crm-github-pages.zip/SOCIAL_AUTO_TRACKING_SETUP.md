# Benabella Social Auto Tracking

The CRM is ready to auto-pull social numbers from a secure connector URL.

Do not put Instagram, TikTok, or Facebook passwords inside the CRM. The connector should use official API tokens and return clean JSON.

## Connector JSON

The CRM expects this shape:

```json
{
  "accounts": [
    {
      "platform": "Instagram",
      "name": "@benabellarealty",
      "followers": 1200,
      "previousFollowers": 1140
    }
  ],
  "posts": [
    {
      "platform": "Instagram",
      "externalId": "post_123",
      "type": "Reel",
      "date": "2026-05-30",
      "url": "https://instagram.com/p/example",
      "caption": "Apartment in Agadir",
      "metrics": {
        "views": 2500,
        "likes": 140,
        "comments": 12,
        "shares": 8,
        "saves": 20,
        "messages": 4,
        "leads": 2
      }
    }
  ]
}
```

## CRM Steps

1. Open the CRM.
2. Go to Social.
3. Paste the secure connector URL in Automatic Tracking.
4. Turn on Auto.
5. Click Save Auto Sync.
6. Click Sync Now once.

After that, the CRM refreshes automatically and saves the numbers to Firebase.

## Official API Notes

- Instagram and Facebook should be connected through Meta Graph API with a business/professional account.
- TikTok should be connected through TikTok's official developer APIs.
- A static GitHub Pages site cannot safely store API secrets by itself.
