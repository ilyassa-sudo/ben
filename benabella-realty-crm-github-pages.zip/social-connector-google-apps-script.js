/**
 * Benabella Realty CRM Social Connector
 *
 * Use this in Google Apps Script as a secure connector URL for the CRM.
 * Keep tokens in Script Properties, never inside the public GitHub Pages CRM.
 *
 * Script Properties:
 * TIKTOK_ACCESS_TOKEN = your TikTok OAuth access token
 * TIKTOK_USERNAME = benabella.realty
 */

const CRM_CONNECTOR_VERSION = "2026-05-30";

function doGet() {
  const payload = {
    version: CRM_CONNECTOR_VERSION,
    accounts: [],
    posts: []
  };

  const tiktok = getTikTokData_();
  if (tiktok) {
    payload.accounts.push(tiktok.account);
    payload.posts.push(...tiktok.posts);
  }

  return ContentService
    .createTextOutput(JSON.stringify(payload))
    .setMimeType(ContentService.MimeType.JSON);
}

function getTikTokData_() {
  const props = PropertiesService.getScriptProperties();
  const token = props.getProperty("TIKTOK_ACCESS_TOKEN");
  const username = props.getProperty("TIKTOK_USERNAME") || "benabella.realty";

  if (!token) {
    return {
      account: {
        platform: "TikTok",
        name: `@${username}`,
        followers: 0,
        previousFollowers: 0
      },
      posts: []
    };
  }

  const userInfo = fetchTikTokUserInfo_(token, username);
  const videos = fetchTikTokVideos_(token);

  return {
    account: {
      platform: "TikTok",
      name: `@${username}`,
      followers: Number(userInfo.follower_count) || 0,
      previousFollowers: Number(userInfo.follower_count) || 0
    },
    posts: videos.map((video) => ({
      platform: "TikTok",
      externalId: String(video.id || ""),
      type: "Video",
      date: video.create_time ? new Date(Number(video.create_time) * 1000).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10),
      url: video.share_url || video.embed_link || "",
      caption: video.video_description || video.title || "",
      metrics: {
        views: Number(video.view_count) || 0,
        likes: Number(video.like_count) || 0,
        comments: Number(video.comment_count) || 0,
        shares: Number(video.share_count) || 0,
        saves: 0,
        messages: 0,
        leads: 0
      }
    }))
  };
}

function fetchTikTokUserInfo_(token, username) {
  const url = "https://open.tiktokapis.com/v2/research/user/info/?fields=display_name,bio_description,avatar_url,is_verified,follower_count,following_count,likes_count,video_count";
  const response = UrlFetchApp.fetch(url, {
    method: "post",
    contentType: "application/json",
    headers: {
      Authorization: `Bearer ${token}`
    },
    payload: JSON.stringify({ username }),
    muteHttpExceptions: true
  });
  const body = JSON.parse(response.getContentText() || "{}");
  return body.data || {};
}

function fetchTikTokVideos_(token) {
  const url = "https://open.tiktokapis.com/v2/video/list/?fields=id,create_time,share_url,video_description,title,like_count,comment_count,share_count,view_count";
  const response = UrlFetchApp.fetch(url, {
    method: "post",
    contentType: "application/json",
    headers: {
      Authorization: `Bearer ${token}`
    },
    payload: JSON.stringify({ max_count: 20 }),
    muteHttpExceptions: true
  });
  const body = JSON.parse(response.getContentText() || "{}");
  return body.data?.videos || body.data?.video_list || [];
}
